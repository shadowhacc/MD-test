// base by shadowBot
console.clear();
const { 
    default: makeWASocket, 
    useMultiFileAuthState, 
    DisconnectReason, 
    fetchLatestBaileysVersion,
    jidDecode, 
    downloadContentFromMessage, 
    Browsers,
    MessageRetryMap 
} = require("@whiskeysockets/baileys");
const axios = require('axios');
const pino = require('pino');
const readline = require("readline");
const fs = require('fs');
const chalk = require("chalk");
const crypto = require('crypto');
const { Boom } = require('@hapi/boom');
const {
  smsg,
  getBuffer,
  getSizeMedia,
  sleep
} = require('./lib/myfunc');
const rl = readline.createInterface({ input: process.stdin, output: process.stdout })
const question = (text) => {
    return new Promise((resolve) => { rl.question(text, resolve) });
}

// Initialize Global Variables
global.autoTyping = true;
global.autostatusview = true;
global.antiDelete = true;
global.autoReact = true;

// Auto Typing Function
const simulateTyping = async (jid) => {
    if (!global.autoTyping) return;
    try {
        await shadow.sendPresenceUpdate('composing', jid);
        setTimeout(async () => {
            await shadow.sendPresenceUpdate('paused', jid);
        }, 1000);
    } catch (err) {
        // Silent fail
    }
};

// Message Cache for Anti-Delete
let messageCache = {};

// Emojis for Auto React
const emojis = [
'🔥','⚡','💥','💯','🚀','🎯','👑','💎','🛡️','⚔️',
'😎','🤖','👻','💀','☠️','👽','🧠','👀','🫡','🤝',
'👍','👎','👌','✌️','👏','🙌','🙏','🤟','🤞','👊',
'❤️','🩷','🧡','💛','💚','💙','💜','🖤','🤍','🤎',
'💖','💘','💝','💕','💞','💓','💗','💟','❣️','💌',
'💋','💤','💦','💨','🕊️','🦋','🌸','🌹','🌺','🌻',
'🍀','🌈','⭐','🌟','✨','🌙','☀️','🌤️','🌦️','🌧️',
'⛈️','🌩️','❄️','💧','🌊','🌪️','🌫️','🪐','🌍','🌎',
'🌏','🌌','🪁','🛸','🛶','⛵','🚤','🚁','🛩️','✈️',
'🛫','🛬','🛎️','🎁','🎈','🎉','🎊','🎃','🎄','🎆',
'🎇','🎵','🎶','🎼','🎤','🎧','🎹','🥁','🪘','🎷',
'🎺','🪗','🪕','🎸','🏆','🏅','🥇','🥈','🥉','🎖️',
'🏵️','🎗️','🏹','🥊','🥋','🎽','⛸️','🎿','🛷','🥌',
'🎯','🪀','🪁','🎱','🔮','🧿','🪬','💈','⚙️','🛠️',
'🗡️','🛡️','🪓','🔫','💣','🧨','🪃','🪀','🧲','💡',
'🔦','🏮','🪔','🕯️','🧯','🛒','🛍️','📿','📯','📻',
'🎙️','📺','📷','📸','📹','🎥','📽️','🎞️','📞','☎️',
'📟','📠','📱','📲','💻','🖥️','🖨️','⌨️','🖱️','🖲️',
'💽','💾','💿','📀','🧮','🎛️','🎚️','🧭','🗺️','🗿',
'🏔️','⛰️','🌋','🗻','🏕️','🏖️','🏜️','🏝️','🏞️','🏟️',
'🏛️','🏗️','🧱','🪨','🪵','🛖','🏠','🏡','🏘️','🏚️',
'🏢','🏬','🏣','🏤','🏥','🏦','🏨','🏪','🏫','🏩',
'💒','⛪','🕌','🕍','🛕','🕋','⛩️','🛤️','🛣️','🗽',
'🗼','🏯','🏰','🔱','⚖️','🪖','🧱','🪓','🪃','🪀',
'🪁','🛷','🛹','⛸️','🏒','🥍','🏑','🥅','🧸','🪀',
'🪁','🛹','🛷','🛡️','⚔️','☠️','💀','👻','👽','🤖',
'🧟','🧛','🧞','🧚','🧜','🦹','🦸','🦇','🐉','🐲',
'🕷️','🕸️','🦂','🦑','🦈','🐍','🦕','🦖','🦓','🦍',
'🦏','🐅','🐆','🦌','🦢','🦉','🦅','🦚','🦜','🦂',
'🪳','🦟','🦠','💉','🩸','🩹','🩺','🧪','⚰️','⚱️',
'🪦','🛡️','⚔️','🔪','🗡️','🪓','🪃','🪀','🪁','💣',
'🧨','🛡️','☠️','💀','👻','👽','🧠','👁️','👀','🫥',
'😈','👿','🤡','🫣','🥶','🥵','🥴','🥳','🤯','😱',
'😨','😰','😥','😓','🤬','🫡','🤝','👊','🤛','🤜',
'🤚','✋','🖐️','🖖','👌','🤌','🤏','✌️','🤟','🤘',
'🤙','👈','👉','👆','👇','☝️','🫵','🫂','💪','🦾',
'🦿','🦵','🦶','👣','🦷','🦴','🫀','🫁','🧠','🫂'
];

async function connectToWhatsApp() {
    const { state, saveCreds } = await useMultiFileAuthState("./session");
    
    // Small Clean Console Banner
    console.log(chalk.hex("#FF5733")("╔══════════════════════╗"));
    console.log(chalk.hex("#FF5733")("║   SHADOW Bot     ║"));
    console.log(chalk.hex("#FF5733")("╚══════════════════════╝"));
    console.log(chalk.hex("#33FF57")(`⚡ Version: 10.0`));
    console.log(chalk.hex("#33FF57")(`👑 Developer: SHADOW OFFICIAL`));
    console.log(chalk.hex("#33FF57")(`📱 Contact: 923476668273`));
    console.log(chalk.hex("#33FF57")(`🕒 ${new Date().toLocaleTimeString()}`));
    console.log("");
    
    const shadow = makeWASocket({
        printQRInTerminal: false,
        syncFullHistory: true,
        markOnlineOnConnect: true,
        connectTimeoutMs: 30000,
        defaultQueryTimeoutMs: 0,
        keepAliveIntervalMs: 8000,
        generateHighQualityLinkPreview: true, 
        version: (await (await fetch('https://raw.githubusercontent.com/WhiskeySockets/Baileys/master/src/Defaults/baileys-version.json')).json()).version,
        browser: ["Ubuntu", "Chrome", "20.0.04"],
        logger: pino({ level: 'silent' }),
        auth: state
    });

    if (!shadow.authState.creds.registered) {
        console.log(chalk.hex("#FFD700")("\n╔══════════════════════╗"));
        console.log(chalk.hex("#FFD700")("║ Registration Needed  ║"));
        console.log(chalk.hex("#FFD700")("╚══════════════════════╝"));
        
        const phoneNumber = await question(chalk.hex("#00FFFF")(`Enter number: `));
        const code = await shadow.requestPairingCode(phoneNumber, "SHADOW78");
        
        console.log(chalk.hex("#00FF00")("\n╔══════════════════════╗"));
        console.log(chalk.hex("#00FF00")(`║ Code: ${code}    ║`));
        console.log(chalk.hex("#00FF00")("╚══════════════════════╝"));
    }

    const store = {};
    
    shadow.decodeJid = (jid) => {
        if (!jid) return jid;
        if (/:\d+@/gi.test(jid)) {
            let decode = jidDecode(jid) || {};
            return decode.user && decode.server && decode.user + '@' + decode.server || jid;
        } else return jid;
    };

    // MESSAGE HANDLER
    shadow.ev.on('messages.upsert', async chatUpdate => {
        try {
            mek = chatUpdate.messages[0];
            if (!mek.message) return;
            
            mek.message = (Object.keys(mek.message)[0] === 'ephemeralMessage') ? mek.message.ephemeralMessage.message : mek.message;
            
            // Auto Status View
            if (global.autostatusview && mek.key && mek.key.remoteJid === 'status@broadcast') {
                await shadow.readMessages([mek.key]);
            };
            
            if (!shadow.public && !mek.key.fromMe && chatUpdate.type === 'notify') return;
            
            if (mek.key.id.startsWith('SHADOW') && mek.key.id.length === 16) return;
            
            let m = smsg(shadow, mek, store);
            
            // Auto Typing Simulation
            if (global.autoTyping && !mek.key.fromMe) {
                simulateTyping(mek.key.remoteJid);
            }
            
            // Cache message for Anti-Delete
            const msgId = mek.key.id;
            if (mek.message && !mek.key.fromMe) {
                messageCache[msgId] = mek;
            }
            
            // Auto React
            if (global.autoReact && !mek.key.fromMe && mek.message) {
                const randomEmoji = emojis[Math.floor(Math.random() * emojis.length)];
                setTimeout(() => {
                    shadow.sendMessage(mek.key.remoteJid, {
                        react: {
                            text: randomEmoji,
                            key: mek.key
                        }
                    }).catch(() => {});
                }, 1000);
            }
            
            // Detect Deleted Messages (Anti-Delete)
            if (global.antiDelete && 
                mek.message?.protocolMessage &&
                mek.message.protocolMessage.type === 0 &&
                !mek.key.fromMe) {
                
                const deletedKey = mek.message.protocolMessage.key.id;
                const originalMsg = messageCache[deletedKey];
                
                if (originalMsg) {
                    // Forward original message
                    await shadow.sendMessage(originalMsg.key.remoteJid, {
                        forward: originalMsg
                    }).catch(() => {});
                    
                    // Send warning
                    await shadow.sendMessage(originalMsg.key.remoteJid, {
                        text: `*Message Delete Ki Koshish Nahi Chalegi!* 🚫\n> *By SHADOW Bot*`,
                        mentions: [originalMsg.key.participant || originalMsg.key.remoteJid]
                    }).catch(() => {});
                    
                    // Clear cache
                    delete messageCache[deletedKey];
                }
            }
            
            // Process command WITHOUT prefix check
            require("./THETEAMSHADOWDEVLOPERS.js")(shadow, m, chatUpdate, store);
            
        } catch (error) {
            console.error(chalk.red("Error:"), error.message);
        }
    });

    // UTILITY FUNCTIONS
    shadow.getFile = async (PATH, save) => {
        let res;
        let data = Buffer.isBuffer(PATH) ? PATH : 
                   /^data:.*?\/.*?;base64,/i.test(PATH) ? Buffer.from(PATH.split`,`[1], 'base64') : 
                   /^https?:\/\//.test(PATH) ? await (res = await getBuffer(PATH)) : 
                   fs.existsSync(PATH) ? fs.readFileSync(PATH) : 
                   Buffer.alloc(0);
        
        return { res, data, size: await getSizeMedia(data) };
    };

    shadow.downloadMediaMessage = async (message) => {
        let mime = (message.msg || message).mimetype || '';
        let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0];
        const stream = await downloadContentFromMessage(message, messageType);
        let buffer = Buffer.from([]);
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
        }
        return buffer;
    };

    shadow.sendText = (jid, text, quoted = '', options) => shadow.sendMessage(jid, { text, ...options }, { quoted });

    shadow.sendImageAsSticker = async (jid, path, quoted, options = {}) => {
        const buff = Buffer.isBuffer(path) ? path : 
                     /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : 
                     /^https?:\/\//.test(path) ? await getBuffer(path) : 
                     fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0);
        
        await shadow.sendMessage(jid, { sticker: { url: buff }, ...options }, { quoted });
        return buff;
    };

    // CONNECTION HANDLERS
    shadow.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect } = update;
        
        if (connection === 'close') {
            console.log(chalk.yellow("\nReconnecting..."));
            const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
            if (shouldReconnect) {
                setTimeout(connectToWhatsApp, 5000);
            } else {
                console.log(chalk.red("Logged out, re-pair needed"));
            }
        } 
        else if (connection === 'open') {
            console.log(chalk.green("\n╔══════════════════════╗"));
            console.log(chalk.green("║   Bot Connected!     ║"));
            console.log(chalk.green("╚══════════════════════╝"));
            console.log(chalk.cyan(`User: ${shadow.user?.name || 'Unknown'}`));
            console.log(chalk.cyan(`Status: Online`));
            
            // Auto set status
            shadow.setStatus("⚡ SHADOW Bot | Online").catch(() => {});
            
            // Send startup message
            const startupMsg = `SADOW Bot Started!\nVersion: 10.0\nOwner: shadow\nStatus: ✅ Online\n\nType 'menu' for commands`;
            
            shadow.sendText(shadow.user.id, startupMsg).catch(() => {});
        }
    });

    shadow.ev.on('error', (err) => {
        console.error(chalk.red("Error:"), err.message);
    });

    shadow.ev.on('creds.update', saveCreds);
    
    // Set Public Mode
    shadow.public = true;
    
    // Set Status Function
    shadow.setStatus = async (status) => {
        try {
            await shadow.query({
                tag: 'iq',
                attrs: { to: '@s.whatsapp.net', type: 'set', xmlns: 'status' },
                content: [{ tag: 'status', attrs: {}, content: Buffer.from(status, 'utf-8') }],
            });
            console.log(chalk.blue(`Status: ${status}`));
        } catch (err) {
            // Silent fail
        }
    };
}

// START BOT
console.log(chalk.hex("#FFD700")("\n╔══════════════════════╗"));
console.log(chalk.hex("#FFD700")("║ Starting SHADOW BOT   ║"));
console.log(chalk.hex("#FFD700")("╚══════════════════════╝"));

connectToWhatsApp();

// Handle process termination
process.on('SIGINT', () => {
    console.log(chalk.yellow("\nShutting down..."));
    rl.close();
    process.exit(0);
});

// Auto clear cache every 30 minutes
setInterval(() => {
    const cacheSize = Object.keys(messageCache).length;
    if (cacheSize > 1000) {
        messageCache = {};
        console.log(chalk.cyan("Cache cleared"));
    }
}, 30 * 60 * 1000);